import React from 'react';
import AdminDashboard from '../../components/Admin/AdminDashboard';

const AdminDashboardPage = () => {
  return <AdminDashboard />;
};

export default AdminDashboardPage;
