import React from 'react';
import ManageEvents from '../../components/Admin/ManageEvents';

const ManageEventsPage = () => {
  return <ManageEvents />;
};

export default ManageEventsPage;
