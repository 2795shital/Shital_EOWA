import React from 'react';
import ManageVendors from '../../components/Admin/ManageVendors';

const ManageVendorsPage = () => {
  return <ManageVendors />;
};

export default ManageVendorsPage;
