import React from 'react';
import ManageCustomers from '../../components/Admin/ManageCustomers';

const ManageCustomersPage = () => {
  return <ManageCustomers />;
};

export default ManageCustomersPage;
