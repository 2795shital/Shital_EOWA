import React from 'react';
import Profile from '../../components/Customer/Profile';

const ProfilePage = () => {
  return <Profile />;
};

export default ProfilePage;
