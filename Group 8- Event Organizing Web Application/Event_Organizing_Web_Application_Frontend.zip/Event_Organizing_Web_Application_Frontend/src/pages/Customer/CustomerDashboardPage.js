import React from 'react';
import CustomerDashboard from '../../components/Customer/CustomerDashboard';

const CustomerDashboardPage = () => {
  return <CustomerDashboard />;
};

export default CustomerDashboardPage;
