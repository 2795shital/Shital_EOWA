export const API_BASE_URL = 'https://example.com/api';

export const STATUS_PENDING = 'pending';
export const STATUS_CONFIRMED = 'confirmed';
export const STATUS_CANCELLED = 'cancelled';
